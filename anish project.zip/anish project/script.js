// Script to open and close modal
window.addEventListener('load', function () {
    document.querySelector('.hero').classList.add('animate-fade-in');
  });

document.getElementById('get-started-btn').addEventListener('click', function() {
    document.getElementById('modal').style.display = 'block';
  });
  
  document.querySelector('.close').addEventListener('click', function() {
    document.getElementById('modal').style.display = 'none';
  });
  
  window.addEventListener('click', function(event) {
    if (event.target === document.getElementById('modal')) {
      document.getElementById('modal').style.display = 'none';
    }
  });
  