import React from "react"

const App = () => {
  return <p>Hello, Web3!</p>
}

export default App;